pg_dump: last built-in OID is 16383
pg_dump: reading extensions
pg_dump: identifying extension members
pg_dump: reading schemas
pg_dump: reading user-defined tables
pg_dump: reading user-defined functions
pg_dump: reading user-defined types
pg_dump: reading procedural languages
pg_dump: reading user-defined aggregate functions
pg_dump: reading user-defined operators
pg_dump: reading user-defined access methods
pg_dump: reading user-defined operator classes
pg_dump: reading user-defined operator families
pg_dump: reading user-defined text search parsers
pg_dump: reading user-defined text search templates
pg_dump: reading user-defined text search dictionaries
pg_dump: reading user-defined text search configurations
pg_dump: reading user-defined foreign-data wrappers
pg_dump: reading user-defined foreign servers
pg_dump: reading default privileges
pg_dump: reading user-defined collations
pg_dump: reading user-defined conversions
pg_dump: reading type casts
pg_dump: reading transforms
pg_dump: reading table inheritance information
pg_dump: reading event triggers
pg_dump: finding extension tables
pg_dump: finding inheritance relationships
pg_dump: reading column info for interesting tables
pg_dump: finding table default expressions
pg_dump: flagging inherited columns in subtables
pg_dump: reading partitioning data
pg_dump: reading indexes
pg_dump: flagging indexes in partitioned tables
pg_dump: reading extended statistics
pg_dump: reading constraints
pg_dump: reading triggers
pg_dump: reading rewrite rules
pg_dump: reading policies
pg_dump: reading row-level security policies
pg_dump: reading publications
pg_dump: reading publication membership of tables
pg_dump: reading publication membership of schemas
pg_dump: reading subscriptions
pg_dump: reading large objects
pg_dump: reading dependency data
pg_dump: saving encoding = UTF8
pg_dump: saving standard_conforming_strings = on
pg_dump: saving search_path = 
pg_dump: creating TABLE "public.alembic_version"
pg_dump: creating TABLE "public.categoria"
pg_dump: creating SEQUENCE "public.categoria_id_categoria_seq"
pg_dump: creating SEQUENCE OWNED BY "public.categoria_id_categoria_seq"
pg_dump: creating TABLE "public.clientes"
pg_dump: creating SEQUENCE "public.clientes_id_cliente_seq"
pg_dump: creating SEQUENCE OWNED BY "public.clientes_id_cliente_seq"
pg_dump: creating TABLE "public.detalles_orden"
pg_dump: creating SEQUENCE "public.detalles_orden_id_detalle_seq"
pg_dump: creating SEQUENCE OWNED BY "public.detalles_orden_id_detalle_seq"
pg_dump: creating TABLE "public.favoritos"
pg_dump: creating SEQUENCE "public.favoritos_id_favorito_seq"
--
-- PostgreSQL database dump
--

\restrict p4VXQqcnpExMNNQb24KkayNQxyD83JS5JMjfsdR5lSPtTPrFC6jZko6xcZaRiSW

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

-- Started on 2026-01-22 21:55:53 -03

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 239 (class 1259 OID 18173)
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 18019)
-- Name: categoria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoria (
    id_categoria integer NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text,
    activa boolean
);


--
-- TOC entry 217 (class 1259 OID 18018)
-- Name: categoria_id_categoria_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categoria_id_categoria_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3585 (class 0 OID 0)
-- Dependencies: 217
-- Name: categoria_id_categoria_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categoria_id_categoria_seq OWNED BY public.categoria.id_categoria;


--
-- TOC entry 222 (class 1259 OID 18039)
-- Name: clientes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes (
    id_cliente integer NOT NULL,
    nombre_cliente character varying(100) NOT NULL,
    apellido_cliente character varying(100) NOT NULL,
    dni_cuit character varying(50) NOT NULL,
    email_cliente character varying(100) NOT NULL,
    telefono character varying(100) NOT NULL,
    direccion_cliente text NOT NULL,
    ciudad_cliente character varying(100) NOT NULL,
    codigo_postal character varying(20) NOT NULL,
    provincia_cliente character varying(20) NOT NULL,
    fecha_registro timestamp without time zone
);


--
-- TOC entry 221 (class 1259 OID 18038)
-- Name: clientes_id_cliente_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clientes_id_cliente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3586 (class 0 OID 0)
-- Dependencies: 221
-- Name: clientes_id_cliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clientes_id_cliente_seq OWNED BY public.clientes.id_cliente;


--
-- TOC entry 236 (class 1259 OID 18144)
-- Name: detalles_orden; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.detalles_orden (
    id_detalle integer NOT NULL,
    id_orden integer,
    id_producto integer,
    cantidad integer NOT NULL,
    precio_unitario numeric(10,2) NOT NULL
);


--
-- TOC entry 235 (class 1259 OID 18143)
-- Name: detalles_orden_id_detalle_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.detalles_orden_id_detalle_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3587 (class 0 OID 0)
-- Dependencies: 235
-- Name: detalles_orden_id_detalle_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.detalles_orden_id_detalle_seq OWNED BY public.detalles_orden.id_detalle;


--
-- TOC entry 234 (class 1259 OID 18127)
-- Name: favoritos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.favoritos (
    id_favorito integer NOT NULL,
    id_cliente integer NOT NULL,
    id_producto integer NOT NULL,
    fecha_agregado timestamp without time zone
);


--
-- TOC entry 233 (class 1259 OID 18126)
-- Name: favoritos_id_favorito_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE ppg_dump: creating SEQUENCE OWNED BY "public.favoritos_id_favorito_seq"
pg_dump: creating TABLE "public.imagenes_productos"
pg_dump: creating SEQUENCE "public.imagenes_productos_id_imagen_seq"
pg_dump: creating SEQUENCE OWNED BY "public.imagenes_productos_id_imagen_seq"
pg_dump: creating TABLE "public.inventario"
pg_dump: creating SEQUENCE "public.inventario_id_inventario_seq"
pg_dump: creating SEQUENCE OWNED BY "public.inventario_id_inventario_seq"
pg_dump: creating TABLE "public.ordenes"
pg_dump: creating SEQUENCE "public.ordenes_id_orden_seq"
pg_dump: creating SEQUENCE OWNED BY "public.ordenes_id_orden_seq"
pg_dump: creating TABLE "public.pagos"
pg_dump: creating SEQUENCE "public.pagos_id_pago_seq"
pg_dump: creating SEQUENCE OWNED BY "public.pagos_id_pago_seq"
pg_dump: creating TABLE "public.productos"
ublic.favoritos_id_favorito_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3588 (class 0 OID 0)
-- Dependencies: 233
-- Name: favoritos_id_favorito_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.favoritos_id_favorito_seq OWNED BY public.favoritos.id_favorito;


--
-- TOC entry 228 (class 1259 OID 18082)
-- Name: imagenes_productos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.imagenes_productos (
    id_imagen integer NOT NULL,
    id_producto integer,
    url_imagen text NOT NULL,
    imagen_principal boolean,
    descripcion text
);


--
-- TOC entry 227 (class 1259 OID 18081)
-- Name: imagenes_productos_id_imagen_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.imagenes_productos_id_imagen_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3589 (class 0 OID 0)
-- Dependencies: 227
-- Name: imagenes_productos_id_imagen_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.imagenes_productos_id_imagen_seq OWNED BY public.imagenes_productos.id_imagen;


--
-- TOC entry 230 (class 1259 OID 18096)
-- Name: inventario; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventario (
    id_inventario integer NOT NULL,
    id_producto integer,
    cantidad_stock integer NOT NULL,
    ubicacion character varying(100),
    stock_minimo integer,
    utlima_actualizacion timestamp without time zone
);


--
-- TOC entry 229 (class 1259 OID 18095)
-- Name: inventario_id_inventario_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventario_id_inventario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3590 (class 0 OID 0)
-- Dependencies: 229
-- Name: inventario_id_inventario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventario_id_inventario_seq OWNED BY public.inventario.id_inventario;


--
-- TOC entry 232 (class 1259 OID 18110)
-- Name: ordenes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ordenes (
    id_orden integer NOT NULL,
    id_cliente integer,
    id_usuarios integer,
    fecha_creacion timestamp without time zone,
    estado character varying(50),
    monto_total numeric(10,2)
);


--
-- TOC entry 231 (class 1259 OID 18109)
-- Name: ordenes_id_orden_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ordenes_id_orden_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3591 (class 0 OID 0)
-- Dependencies: 231
-- Name: ordenes_id_orden_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ordenes_id_orden_seq OWNED BY public.ordenes.id_orden;


--
-- TOC entry 238 (class 1259 OID 18161)
-- Name: pagos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pagos (
    id_pago integer NOT NULL,
    id_orden integer,
    mp_preference_id character varying(150),
    mp_payment_id character varying(150),
    mp_estado character varying(50),
    mp_tipo_pago character varying(50),
    monto_cobrado_mp numeric(10,2),
    fecha_pago timestamp without time zone
);


--
-- TOC entry 237 (class 1259 OID 18160)
-- Name: pagos_id_pago_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pagos_id_pago_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3592 (class 0 OID 0)
-- Dependencies: 237
-- Name: pagos_id_pago_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pagos_id_pago_seq OWNED BY public.pagos.id_pago;


--
-- TOC entry 226 (class 1259 OID 18066)
-- Name: productos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.productos (
    id_producto integer NOT NULL,
    sku character varying(50),
    nombre character varying(100) NOT NULL,
    descripcion text,
    precio numeric(10,2) NOTpg_dump: creating SEQUENCE "public.productos_id_producto_seq"
pg_dump: creating SEQUENCE OWNED BY "public.productos_id_producto_seq"
pg_dump: creating TABLE "public.proovedores"
pg_dump: creating SEQUENCE "public.proovedores_id_proovedor_seq"
pg_dump: creating SEQUENCE OWNED BY "public.proovedores_id_proovedor_seq"
pg_dump: creating TABLE "public.roles"
pg_dump: creating SEQUENCE "public.roles_id_rol_seq"
pg_dump: creating SEQUENCE OWNED BY "public.roles_id_rol_seq"
pg_dump: creating TABLE "public.usuarios"
pg_dump: creating SEQUENCE "public.usuarios_id_usuarios_seq"
pg_dump: creating SEQUENCE OWNED BY "public.usuarios_id_usuarios_seq"
pg_dump: creating DEFAULT "public.categoria id_categoria"
pg_dump: creating DEFAULT "public.clientes id_cliente"
pg_dump: creating DEFAULT "public.detalles_orden id_detalle"
 NULL,
    alto_cm numeric(5,2),
    ancho_cm numeric(5,2),
    profundidad_cm numeric(5,2),
    material character varying(100) NOT NULL,
    id_categoria integer,
    fecha_creacion timestamp without time zone,
    activo boolean DEFAULT true NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 18065)
-- Name: productos_id_producto_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.productos_id_producto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3593 (class 0 OID 0)
-- Dependencies: 225
-- Name: productos_id_producto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.productos_id_producto_seq OWNED BY public.productos.id_producto;


--
-- TOC entry 220 (class 1259 OID 18030)
-- Name: proovedores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.proovedores (
    id_proovedor integer NOT NULL,
    nombre_empresa character varying(100),
    contacto_nombre character varying(100),
    telefono character varying(100),
    email character varying(100),
    direccion text,
    activo boolean
);


--
-- TOC entry 219 (class 1259 OID 18029)
-- Name: proovedores_id_proovedor_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.proovedores_id_proovedor_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3594 (class 0 OID 0)
-- Dependencies: 219
-- Name: proovedores_id_proovedor_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.proovedores_id_proovedor_seq OWNED BY public.proovedores.id_proovedor;


--
-- TOC entry 216 (class 1259 OID 18008)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id_rol integer NOT NULL,
    nombre_rol character varying(50) NOT NULL,
    descripcion text
);


--
-- TOC entry 215 (class 1259 OID 18007)
-- Name: roles_id_rol_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_rol_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3595 (class 0 OID 0)
-- Dependencies: 215
-- Name: roles_id_rol_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_rol_seq OWNED BY public.roles.id_rol;


--
-- TOC entry 224 (class 1259 OID 18052)
-- Name: usuarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuarios (
    id_usuarios integer NOT NULL,
    nombre_us character varying(50) NOT NULL,
    apellido_us character varying(50) NOT NULL,
    email_us character varying(100) NOT NULL,
    password_hash character varying(200) NOT NULL,
    id_rol integer,
    activo boolean,
    fecha_creacion timestamp without time zone,
    fecha_actualizacion timestamp without time zone
);


--
-- TOC entry 223 (class 1259 OID 18051)
-- Name: usuarios_id_usuarios_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.usuarios_id_usuarios_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3596 (class 0 OID 0)
-- Dependencies: 223
-- Name: usuarios_id_usuarios_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.usuarios_id_usuarios_seq OWNED BY public.usuarios.id_usuarios;


--
-- TOC entry 3349 (class 2604 OID 18022)
-- Name: categoria id_categoria; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoria ALTER COLUMN id_categoria SET DEFAULT nextval('public.categoria_id_categoria_seq'::regclass);


--
-- TOC entry 3351 (class 2604 OID 18042)
-- Name: clientes id_cliente; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes ALTER COLUMN id_cliente SET DEFAULT nextval('public.clientes_id_cliente_seq'::regclass);


--
-- TOC entry 3359 (class 2604 OID 18147)
-- Name: detalles_orden id_detalle; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalles_orden ALTER COLUMN id_detalle SET DEFAULT nextval('public.detalles_orden_id_pg_dump: creating DEFAULT "public.favoritos id_favorito"
pg_dump: creating DEFAULT "public.imagenes_productos id_imagen"
pg_dump: creating DEFAULT "public.inventario id_inventario"
pg_dump: creating DEFAULT "public.ordenes id_orden"
pg_dump: creating DEFAULT "public.pagos id_pago"
pg_dump: creating DEFAULT "public.productos id_producto"
pg_dump: creating DEFAULT "public.proovedores id_proovedor"
pg_dump: creating DEFAULT "public.roles id_rol"
pg_dump: creating DEFAULT "public.usuarios id_usuarios"
pg_dump: processing data for table "public.alembic_version"
pg_dump: dumping contents of table "public.alembic_version"
pg_dump: processing data for table "public.categoria"
pg_dump: dumping contents of table "public.categoria"
pg_dump: processing data for table "public.clientes"
pg_dump: dumping contents of table "public.clientes"
pg_dump: processing data for table "public.detalles_orden"
detalle_seq'::regclass);


--
-- TOC entry 3358 (class 2604 OID 18130)
-- Name: favoritos id_favorito; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favoritos ALTER COLUMN id_favorito SET DEFAULT nextval('public.favoritos_id_favorito_seq'::regclass);


--
-- TOC entry 3355 (class 2604 OID 18085)
-- Name: imagenes_productos id_imagen; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imagenes_productos ALTER COLUMN id_imagen SET DEFAULT nextval('public.imagenes_productos_id_imagen_seq'::regclass);


--
-- TOC entry 3356 (class 2604 OID 18099)
-- Name: inventario id_inventario; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario ALTER COLUMN id_inventario SET DEFAULT nextval('public.inventario_id_inventario_seq'::regclass);


--
-- TOC entry 3357 (class 2604 OID 18113)
-- Name: ordenes id_orden; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes ALTER COLUMN id_orden SET DEFAULT nextval('public.ordenes_id_orden_seq'::regclass);


--
-- TOC entry 3360 (class 2604 OID 18164)
-- Name: pagos id_pago; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pagos ALTER COLUMN id_pago SET DEFAULT nextval('public.pagos_id_pago_seq'::regclass);


--
-- TOC entry 3353 (class 2604 OID 18069)
-- Name: productos id_producto; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productos ALTER COLUMN id_producto SET DEFAULT nextval('public.productos_id_producto_seq'::regclass);


--
-- TOC entry 3350 (class 2604 OID 18033)
-- Name: proovedores id_proovedor; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proovedores ALTER COLUMN id_proovedor SET DEFAULT nextval('public.proovedores_id_proovedor_seq'::regclass);


--
-- TOC entry 3348 (class 2604 OID 18011)
-- Name: roles id_rol; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id_rol SET DEFAULT nextval('public.roles_id_rol_seq'::regclass);


--
-- TOC entry 3352 (class 2604 OID 18055)
-- Name: usuarios id_usuarios; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id_usuarios SET DEFAULT nextval('public.usuarios_id_usuarios_seq'::regclass);


--
-- TOC entry 3579 (class 0 OID 18173)
-- Dependencies: 239
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
1f4f40e58aa1
\.


--
-- TOC entry 3558 (class 0 OID 18019)
-- Dependencies: 218
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categoria (id_categoria, nombre, descripcion, activa) FROM stdin;
1	Sofás	Sofás y sillones para living	t
2	Sillas	Sillas para comedor y oficina	t
3	Mesas	Mesas de comedor, ratona y escritorio	t
4	Camas	Camas y sommiers	t
5	Estanterías	Bibliotecas y modulares	t
\.


--
-- TOC entry 3562 (class 0 OID 18039)
-- Dependencies: 222
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes (id_cliente, nombre_cliente, apellido_cliente, dni_cuit, email_cliente, telefono, direccion_cliente, ciudad_cliente, codigo_postal, provincia_cliente, fecha_registro) FROM stdin;
1	Roberto	Fernández	20-34567890-1	roberto.fernandez@gmail.com	11-4567-8901	Av. Corrientes 1234	Buenos Aires	1043	Buenos Aires	2026-01-23 00:10:48.771642
2	Laura	Sánchez	27-45678901-2	laura.sanchez@hotmail.com	11-5678-9012	Calle Falsa 123	La Plata	1900	Buenos Aires	2026-01-23 00:10:48.771647
3	Diego	Torres	20-56789012-3	diego.torres@yahoo.com	341-678-9012	San Martín 456	Rosario	2000	Santa Fe	2026-01-23 00:10:48.771649
4	Sofía	Ramírez	27-67890123-4	sofia.ramirez@outlook.com	351-789-0123	Belgrano 789	Córdoba	5000	Córdoba	2026-01-23 00:10:48.771651
5	Martín	López	20-78901234-5	martin.lopez@gmail.com	261-890-1234	Las Heras 321	Mendoza	5500	Mendoza	2026-01-23 00:10:48.771653
\.


--
-- TOC entry 3576 (class 0 OID 18144)
-- Dependencies: 236
-- Data for Name: detalles_orden; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.detalles_orden (id_detalle, id_orden, id_productpg_dump: dumping contents of table "public.detalles_orden"
pg_dump: processing data for table "public.favoritos"
pg_dump: dumping contents of table "public.favoritos"
pg_dump: processing data for table "public.imagenes_productos"
pg_dump: dumping contents of table "public.imagenes_productos"
pg_dump: processing data for table "public.inventario"
pg_dump: dumping contents of table "public.inventario"
pg_dump: processing data for table "public.ordenes"
pg_dump: dumping contents of table "public.ordenes"
pg_dump: processing data for table "public.pagos"
pg_dump: dumping contents of table "public.pagos"
pg_dump: processing data for table "public.productos"
pg_dump: dumping contents of table "public.productos"
o, cantidad, precio_unitario) FROM stdin;
1	1	15	2	320000.00
2	1	5	2	95000.00
3	1	1	3	450000.00
4	2	1	2	450000.00
5	2	10	2	520000.00
6	2	3	2	320000.00
7	2	9	1	320000.00
8	3	7	1	185000.00
9	3	4	3	280000.00
10	3	11	1	780000.00
11	3	13	1	145000.00
12	4	13	1	145000.00
13	4	2	1	680000.00
14	4	5	3	95000.00
15	4	10	2	520000.00
16	5	15	1	320000.00
17	5	1	3	450000.00
18	5	6	1	185000.00
19	6	10	3	520000.00
20	7	5	3	95000.00
21	7	6	1	185000.00
22	8	13	3	145000.00
23	8	15	2	320000.00
24	8	3	3	320000.00
25	9	9	1	320000.00
26	9	12	2	280000.00
27	9	3	3	320000.00
28	10	6	1	185000.00
29	10	1	2	450000.00
30	10	2	3	680000.00
\.


--
-- TOC entry 3574 (class 0 OID 18127)
-- Dependencies: 234
-- Data for Name: favoritos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.favoritos (id_favorito, id_cliente, id_producto, fecha_agregado) FROM stdin;
\.


--
-- TOC entry 3568 (class 0 OID 18082)
-- Dependencies: 228
-- Data for Name: imagenes_productos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.imagenes_productos (id_imagen, id_producto, url_imagen, imagen_principal, descripcion) FROM stdin;
\.


--
-- TOC entry 3570 (class 0 OID 18096)
-- Dependencies: 230
-- Data for Name: inventario; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventario (id_inventario, id_producto, cantidad_stock, ubicacion, stock_minimo, utlima_actualizacion) FROM stdin;
8	8	29	Depósito Principal	5	2026-01-22 21:49:40.36611
14	14	21	Depósito Principal	5	2026-01-22 21:49:40.366115
7	7	11	Depósito Principal	5	2026-01-22 21:50:01.474725
4	4	27	Depósito Principal	5	2026-01-22 21:50:01.481617
11	11	31	Depósito Principal	5	2026-01-22 21:50:01.491255
2	2	30	Depósito Principal	5	2026-01-22 21:50:01.511998
5	5	24	Depósito Principal	5	2026-01-22 21:50:01.516003
1	1	42	Depósito Principal	5	2026-01-22 21:50:01.532316
6	6	43	Depósito Principal	5	2026-01-22 21:50:01.534579
10	10	24	Depósito Principal	5	2026-01-22 21:50:01.545372
13	13	25	Depósito Principal	5	2026-01-22 21:50:01.567449
15	15	21	Depósito Principal	5	2026-01-22 21:50:01.570493
9	9	26	Depósito Principal	5	2026-01-22 21:50:01.587014
12	12	40	Depósito Principal	5	2026-01-22 21:50:01.589854
3	3	12	Depósito Principal	5	2026-01-22 21:50:01.592778
\.


--
-- TOC entry 3572 (class 0 OID 18110)
-- Dependencies: 232
-- Data for Name: ordenes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ordenes (id_orden, id_cliente, id_usuarios, fecha_creacion, estado, monto_total) FROM stdin;
1	1	4	2026-01-02 21:50:01.432135	pendiente	2180000.00
2	5	2	2026-01-01 21:50:01.452718	pendiente	2900000.00
3	5	4	2025-12-23 21:50:01.470458	completada	1950000.00
4	5	1	2026-01-11 21:50:01.502396	completada	2150000.00
5	5	4	2026-01-05 21:50:01.52244	completada	1855000.00
6	1	1	2025-12-29 21:50:01.538984	completada	1560000.00
7	4	4	2026-01-18 21:50:01.550634	en_proceso	470000.00
8	1	1	2025-12-28 21:50:01.561248	completada	2035000.00
9	3	1	2025-12-30 21:50:01.581541	completada	1840000.00
10	2	2	2026-01-18 21:50:01.596478	pendiente	3125000.00
\.


--
-- TOC entry 3578 (class 0 OID 18161)
-- Dependencies: 238
-- Data for Name: pagos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pagos (id_pago, id_orden, mp_preference_id, mp_payment_id, mp_estado, mp_tipo_pago, monto_cobrado_mp, fecha_pago) FROM stdin;
\.


--
-- TOC entry 3566 (class 0 OID 18066)
-- Dependencies: 226
-- Data for Name: productos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.productos (id_producto, sku, nombre, descripcion, precio, alto_cm, ancho_cm, profundidad_cm, material, id_categoria, fecha_creacion, activo) FROM stdin;
1	SOF-001	Sofá Moderno 3 Cuerpos	Sofá moderno de 3 cuerpos con tapizado en tela premium	450000.00	85.00	210.00	90.00	Tela premium	1	2026-01-23 00:10:48.788867	t
2	SOF-002	Sofá Esquinero L	Sofá esquinero en forma de L con respaldo reclinable	680000.00	90.00	280.00	200.00	Cuero sintético	1	2026-01-23 00:10:48.788871	t
3	SOF-003	Sofá 2 Cuerpos Nórdico	Sofá de 2 cuerpos estilo nórdico minimalista	320000.00	80.00	160.00	85.00	Lino natural	1	2026-01-23 00:10:48.788874	t
4	MES-001	pg_dump: processing data for table "public.proovedores"
pg_dump: dumping contents of table "public.proovedores"
pg_dump: processing data for table "public.roles"
pg_dump: dumping contents of table "public.roles"
pg_dump: processing data for table "public.usuarios"
pg_dump: dumping contents of table "public.usuarios"
pg_dump: executing SEQUENCE SET categoria_id_categoria_seq
pg_dump: executing SEQUENCE SET clientes_id_cliente_seq
Mesa de Comedor Nórdica	Mesa de comedor extensible para 6-8 personas	280000.00	75.00	180.00	90.00	Madera de roble	3	2026-01-23 00:10:48.788876	t
5	MES-002	Mesa Ratona Circular	Mesa ratona circular con tapa de vidrio	95000.00	45.00	90.00	90.00	Madera y vidrio	3	2026-01-23 00:10:48.788877	t
6	MES-003	Mesa de Trabajo Home Office	Mesa de trabajo con cajones laterales	185000.00	75.00	140.00	70.00	MDF laqueado	3	2026-01-23 00:10:48.788879	t
7	SIL-001	Silla Ergonómica Office	Silla ergonómica con soporte lumbar ajustable	185000.00	110.00	60.00	60.00	Malla transpirable	2	2026-01-23 00:10:48.78888	t
8	SIL-002	Silla de Comedor Pack x4	Set de 4 sillas de comedor con respaldo alto	240000.00	95.00	45.00	50.00	Madera y tela	2	2026-01-23 00:10:48.788882	t
9	SIL-003	Silla Gaming Pro	Silla gamer profesional con reposabrazos 4D	320000.00	130.00	70.00	65.00	Cuero y metal	2	2026-01-23 00:10:48.788883	t
10	CAM-001	Cama Queen con Respaldo	Cama Queen size con respaldo tapizado	520000.00	110.00	160.00	200.00	Madera maciza	4	2026-01-23 00:10:48.788885	t
11	CAM-002	Cama King Size Premium	Cama King size con base reforzada	780000.00	120.00	180.00	200.00	Roble americano	4	2026-01-23 00:10:48.788886	t
12	CAM-003	Cama 1 Plaza Juvenil	Cama individual con cajones inferiores	280000.00	90.00	90.00	190.00	Pino laqueado	4	2026-01-23 00:10:48.788888	t
13	EST-001	Biblioteca 5 Estantes	Biblioteca modular de 5 estantes regulables	145000.00	180.00	80.00	30.00	MDF melamínico	5	2026-01-23 00:10:48.788889	t
14	EST-002	Estante Flotante Pack x3	Set de 3 estantes flotantes de pared	65000.00	4.00	80.00	25.00	Madera natural	5	2026-01-23 00:10:48.788891	t
15	EST-003	Modular TV 180cm	Mueble modular para TV con cajones y estantes	320000.00	60.00	180.00	45.00	Roble y metal	5	2026-01-23 00:10:48.788892	t
\.


--
-- TOC entry 3560 (class 0 OID 18030)
-- Dependencies: 220
-- Data for Name: proovedores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.proovedores (id_proovedor, nombre_empresa, contacto_nombre, telefono, email, direccion, activo) FROM stdin;
1	Maderas del Sur S.A.	Ricardo Gómez	11-4321-5678	ventas@maderasdelsur.com.ar	Parque Industrial 123, Quilmes	t
2	Textiles Industriales	Gabriela Vázquez	11-5432-6789	contacto@textilesind.com.ar	Av. San Martín 456, Avellaneda	t
3	Herrajes y Accesorios Premium	Osvaldo Ríos	11-6543-7890	herrajes@premium.com.ar	Ruta 3 Km 45, San Justo	t
\.


--
-- TOC entry 3556 (class 0 OID 18008)
-- Dependencies: 216
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id_rol, nombre_rol, descripcion) FROM stdin;
1	Administrador	Acceso total al sistema
2	Vendedor	Gestión de ventas y clientes
3	Inventario	Gestión de stock y productos
\.


--
-- TOC entry 3564 (class 0 OID 18052)
-- Dependencies: 224
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usuarios (id_usuarios, nombre_us, apellido_us, email_us, password_hash, id_rol, activo, fecha_creacion, fecha_actualizacion) FROM stdin;
1	Juan	Pérez	admin@muebleria.com	pbkdf2:sha256:1000000$9sM79lvXsF2AJ791$1c5c86f40c94191ac55a9f5f52dcf5879ea8c44fe3d242b1e1ab9744177401f4	1	t	2026-01-23 00:10:48.761977	2026-01-23 00:10:48.761982
2	María	González	maria@muebleria.com	pbkdf2:sha256:1000000$B8H3VKBj4qyJZKfA$b19a98775159f2316081edb95ebf4f1e7632f98b2df4db58453f0325f87f4f9d	2	t	2026-01-23 00:10:48.761984	2026-01-23 00:10:48.761986
3	Carlos	Rodríguez	carlos@muebleria.com	pbkdf2:sha256:1000000$kKQFPqyU00qq98SS$438b9cda4dfe6d67d00b16674e18b0a8bdbbfc07d1bd82cfe99d512835f5597f	2	t	2026-01-23 00:10:48.761988	2026-01-23 00:10:48.76199
4	Ana	Martínez	ana@muebleria.com	pbkdf2:sha256:1000000$Ji6iC9hZz7qZkWCX$6ac477a54cde624c3a3aebf77346401b511b6faef6706fe38abfc00cb5dcbd99	3	t	2026-01-23 00:10:48.761992	2026-01-23 00:10:48.761993
\.


--
-- TOC entry 3597 (class 0 OID 0)
-- Dependencies: 217
-- Name: categoria_id_categoria_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categoria_id_categoria_seq', 5, true);


--
-- TOC entry 3598 (class 0 OID 0)
-- Dependencies: 221
-- Name: clientpg_dump: executing SEQUENCE SET detalles_orden_id_detalle_seq
pg_dump: executing SEQUENCE SET favoritos_id_favorito_seq
pg_dump: executing SEQUENCE SET imagenes_productos_id_imagen_seq
pg_dump: executing SEQUENCE SET inventario_id_inventario_seq
pg_dump: executing SEQUENCE SET ordenes_id_orden_seq
pg_dump: executing SEQUENCE SET pagos_id_pago_seq
pg_dump: executing SEQUENCE SET productos_id_producto_seq
pg_dump: executing SEQUENCE SET proovedores_id_proovedor_seq
pg_dump: executing SEQUENCE SET roles_id_rol_seq
pg_dump: executing SEQUENCE SET usuarios_id_usuarios_seq
pg_dump: creating CONSTRAINT "public.alembic_version alembic_version_pkc"
pg_dump: creating CONSTRAINT "public.categoria categoria_nombre_key"
pg_dump: creating CONSTRAINT "public.categoria categoria_pkey"
pg_dump: creating CONSTRAINT "public.clientes clientes_dni_cuit_key"
pg_dump: creating CONSTRAINT "public.clientes clientes_email_cliente_key"
pg_dump: creating CONSTRAINT "public.clientes clientes_pkey"
pg_dump: creating CONSTRAINT "public.detalles_orden detalles_orden_pkey"
pg_dump: creating CONSTRAINT "public.favoritos favoritos_pkey"
es_id_cliente_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_id_cliente_seq', 5, true);


--
-- TOC entry 3599 (class 0 OID 0)
-- Dependencies: 235
-- Name: detalles_orden_id_detalle_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.detalles_orden_id_detalle_seq', 30, true);


--
-- TOC entry 3600 (class 0 OID 0)
-- Dependencies: 233
-- Name: favoritos_id_favorito_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.favoritos_id_favorito_seq', 1, false);


--
-- TOC entry 3601 (class 0 OID 0)
-- Dependencies: 227
-- Name: imagenes_productos_id_imagen_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.imagenes_productos_id_imagen_seq', 1, false);


--
-- TOC entry 3602 (class 0 OID 0)
-- Dependencies: 229
-- Name: inventario_id_inventario_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventario_id_inventario_seq', 15, true);


--
-- TOC entry 3603 (class 0 OID 0)
-- Dependencies: 231
-- Name: ordenes_id_orden_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ordenes_id_orden_seq', 10, true);


--
-- TOC entry 3604 (class 0 OID 0)
-- Dependencies: 237
-- Name: pagos_id_pago_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pagos_id_pago_seq', 1, false);


--
-- TOC entry 3605 (class 0 OID 0)
-- Dependencies: 225
-- Name: productos_id_producto_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.productos_id_producto_seq', 15, true);


--
-- TOC entry 3606 (class 0 OID 0)
-- Dependencies: 219
-- Name: proovedores_id_proovedor_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.proovedores_id_proovedor_seq', 3, true);


--
-- TOC entry 3607 (class 0 OID 0)
-- Dependencies: 215
-- Name: roles_id_rol_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_rol_seq', 3, true);


--
-- TOC entry 3608 (class 0 OID 0)
-- Dependencies: 223
-- Name: usuarios_id_usuarios_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.usuarios_id_usuarios_seq', 4, true);


--
-- TOC entry 3400 (class 2606 OID 18177)
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- TOC entry 3366 (class 2606 OID 18028)
-- Name: categoria categoria_nombre_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_nombre_key UNIQUE (nombre);


--
-- TOC entry 3368 (class 2606 OID 18026)
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (id_categoria);


--
-- TOC entry 3372 (class 2606 OID 18048)
-- Name: clientes clientes_dni_cuit_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_dni_cuit_key UNIQUE (dni_cuit);


--
-- TOC entry 3374 (class 2606 OID 18050)
-- Name: clientes clientes_email_cliente_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_email_cliente_key UNIQUE (email_cliente);


--
-- TOC entry 3376 (class 2606 OID 18046)
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id_cliente);


--
-- TOC entry 3396 (class 2606 OID 18149)
-- Name: detalles_orden detalles_orden_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalles_orden
    ADD CONSTRAINT detalles_orden_pkey PRIMARY KEY (id_detalle);


--
-- TOC entry 3394 (class 2606 OID 18132)
-- Name: favoritos favoritos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favoritos
    ADD CONSTRAINT pg_dump: creating CONSTRAINT "public.imagenes_productos imagenes_productos_pkey"
pg_dump: creating CONSTRAINT "public.inventario inventario_id_producto_key"
pg_dump: creating CONSTRAINT "public.inventario inventario_pkey"
pg_dump: creating CONSTRAINT "public.ordenes ordenes_pkey"
pg_dump: creating CONSTRAINT "public.pagos pagos_pkey"
pg_dump: creating CONSTRAINT "public.productos productos_pkey"
pg_dump: creating CONSTRAINT "public.productos productos_sku_key"
pg_dump: creating CONSTRAINT "public.proovedores proovedores_pkey"
pg_dump: creating CONSTRAINT "public.roles roles_nombre_rol_key"
pg_dump: creating CONSTRAINT "public.roles roles_pkey"
pg_dump: creating CONSTRAINT "public.usuarios usuarios_email_us_key"
pg_dump: creating CONSTRAINT "public.usuarios usuarios_pkey"
pg_dump: creating FK CONSTRAINT "public.detalles_orden detalles_orden_id_orden_fkey"
pg_dump: creating FK CONSTRAINT "public.detalles_orden detalles_orden_id_producto_fkey"
pg_dump: creating FK CONSTRAINT "public.favoritos favoritos_id_cliente_fkey"
pg_dump: creating FK CONSTRAINT "public.favoritos favoritos_id_producto_fkey"
pg_dump: creating FK CONSTRAINT "public.imagenes_productos imagenes_productos_id_producto_fkey"
favoritos_pkey PRIMARY KEY (id_favorito);


--
-- TOC entry 3386 (class 2606 OID 18089)
-- Name: imagenes_productos imagenes_productos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imagenes_productos
    ADD CONSTRAINT imagenes_productos_pkey PRIMARY KEY (id_imagen);


--
-- TOC entry 3388 (class 2606 OID 18103)
-- Name: inventario inventario_id_producto_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario
    ADD CONSTRAINT inventario_id_producto_key UNIQUE (id_producto);


--
-- TOC entry 3390 (class 2606 OID 18101)
-- Name: inventario inventario_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario
    ADD CONSTRAINT inventario_pkey PRIMARY KEY (id_inventario);


--
-- TOC entry 3392 (class 2606 OID 18115)
-- Name: ordenes ordenes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes
    ADD CONSTRAINT ordenes_pkey PRIMARY KEY (id_orden);


--
-- TOC entry 3398 (class 2606 OID 18166)
-- Name: pagos pagos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_pkey PRIMARY KEY (id_pago);


--
-- TOC entry 3382 (class 2606 OID 18073)
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (id_producto);


--
-- TOC entry 3384 (class 2606 OID 18075)
-- Name: productos productos_sku_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_sku_key UNIQUE (sku);


--
-- TOC entry 3370 (class 2606 OID 18037)
-- Name: proovedores proovedores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.proovedores
    ADD CONSTRAINT proovedores_pkey PRIMARY KEY (id_proovedor);


--
-- TOC entry 3362 (class 2606 OID 18017)
-- Name: roles roles_nombre_rol_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_nombre_rol_key UNIQUE (nombre_rol);


--
-- TOC entry 3364 (class 2606 OID 18015)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id_rol);


--
-- TOC entry 3378 (class 2606 OID 18059)
-- Name: usuarios usuarios_email_us_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_email_us_key UNIQUE (email_us);


--
-- TOC entry 3380 (class 2606 OID 18057)
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id_usuarios);


--
-- TOC entry 3409 (class 2606 OID 18150)
-- Name: detalles_orden detalles_orden_id_orden_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalles_orden
    ADD CONSTRAINT detalles_orden_id_orden_fkey FOREIGN KEY (id_orden) REFERENCES public.ordenes(id_orden) ON DELETE CASCADE;


--
-- TOC entry 3410 (class 2606 OID 18155)
-- Name: detalles_orden detalles_orden_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalles_orden
    ADD CONSTRAINT detalles_orden_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.productos(id_producto);


--
-- TOC entry 3407 (class 2606 OID 18133)
-- Name: favoritos favoritos_id_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favoritos
    ADD CONSTRAINT favoritos_id_cliente_fkey FOREIGN KEY (id_cliente) REFERENCES public.clientes(id_cliente);


--
-- TOC entry 3408 (class 2606 OID 18138)
-- Name: favoritos favoritos_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favoritos
    ADD CONSTRAINT favoritos_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.productos(id_producto);


--
-- TOC entry 3403 (class 2606 OID 18090)
-- Name: imagenes_productos imagenes_productos_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTERpg_dump: creating FK CONSTRAINT "public.inventario inventario_id_producto_fkey"
pg_dump: creating FK CONSTRAINT "public.ordenes ordenes_id_cliente_fkey"
pg_dump: creating FK CONSTRAINT "public.ordenes ordenes_id_usuarios_fkey"
pg_dump: creating FK CONSTRAINT "public.pagos pagos_id_orden_fkey"
pg_dump: creating FK CONSTRAINT "public.productos productos_id_categoria_fkey"
pg_dump: creating FK CONSTRAINT "public.usuarios usuarios_id_rol_fkey"
 TABLE ONLY public.imagenes_productos
    ADD CONSTRAINT imagenes_productos_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.productos(id_producto) ON DELETE CASCADE;


--
-- TOC entry 3404 (class 2606 OID 18104)
-- Name: inventario inventario_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventario
    ADD CONSTRAINT inventario_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.productos(id_producto);


--
-- TOC entry 3405 (class 2606 OID 18116)
-- Name: ordenes ordenes_id_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes
    ADD CONSTRAINT ordenes_id_cliente_fkey FOREIGN KEY (id_cliente) REFERENCES public.clientes(id_cliente);


--
-- TOC entry 3406 (class 2606 OID 18121)
-- Name: ordenes ordenes_id_usuarios_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordenes
    ADD CONSTRAINT ordenes_id_usuarios_fkey FOREIGN KEY (id_usuarios) REFERENCES public.usuarios(id_usuarios);


--
-- TOC entry 3411 (class 2606 OID 18167)
-- Name: pagos pagos_id_orden_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_id_orden_fkey FOREIGN KEY (id_orden) REFERENCES public.ordenes(id_orden) ON DELETE CASCADE;


--
-- TOC entry 3402 (class 2606 OID 18076)
-- Name: productos productos_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categoria(id_categoria);


--
-- TOC entry 3401 (class 2606 OID 18060)
-- Name: usuarios usuarios_id_rol_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_id_rol_fkey FOREIGN KEY (id_rol) REFERENCES public.roles(id_rol);


-- Completed on 2026-01-22 21:55:53 -03

--
-- PostgreSQL database dump complete
--

\unrestrict p4VXQqcnpExMNNQb24KkayNQxyD83JS5JMjfsdR5lSPtTPrFC6jZko6xcZaRiSW

